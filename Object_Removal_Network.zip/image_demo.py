# Copyright (c) OpenMMLab. All rights reserved.
import mmcv
import Object_Removal_Network.mmcv_custom   # noqa: F401,F403
import Object_Removal_Network.mmseg_custom   # noqa: F401,F403
from mmseg.apis import inference_segmentor, init_segmentor, show_result_pyplot
from mmseg.core.evaluation import get_palette
from mmcv.runner import load_checkpoint
from mmseg.core import get_classes
import cv2 as cv
import os.path as osp
import os


def test_single_image(model, img_name, out_dir, color_palette, opacity):
    result = inference_segmentor(model, img_name)
    
    # show the results
    if hasattr(model, 'module'):
        model = model.module

    h, w = result[0].shape[:2]
    img = cv.imread(img_name)
    for i in range(h):
        for j in range(w):
            if result[0][i][j] != 12:
                img[i][j][0], img[i][j][1], img[i][j][2] = 0, 0, 0
            else:
                img[i][j][0], img[i][j][1], img[i][j][2] = 255, 255, 255
    
    # save the results
    out_path = osp.join(out_dir, osp.basename(img_name))
    cv.imwrite(out_path, img)


def get_silhouette(input_path, output_path):
    # build the model from a config file and a checkpoint file
    model = init_segmentor('./Object_Removal_Network/configs/ade20k/upernet_internimage_b_512_160k_ade20k.py', checkpoint=None, device='cuda:0')
    checkpoint = load_checkpoint(model, './Object_Removal_Network/trained_checkpoint/latest.pth', map_location='cpu')
    opacity = 0.5
    if 'CLASSES' in checkpoint.get('meta', {}):
        model.CLASSES = checkpoint['meta']['CLASSES']
    else:
        model.CLASSES = get_classes('ade20k')
        
    # check arg.img is directory of a single image.
    if osp.isdir(input_path):
        for img in os.listdir(input_path):
            test_single_image(model, osp.join(input_path, img), output_path, get_palette('ade20k'), opacity)
    else:
        test_single_image(model, input_path, output_path, get_palette('ade20k'), opacity)